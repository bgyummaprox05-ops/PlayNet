# Bu proje için özel ProGuard kuralı gerekmiyor.
# minifyEnabled şu an false; ileride true yaparsanız gerekli kuralları buraya ekleyin.
