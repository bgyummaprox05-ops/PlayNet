package com.plakrafi.musicplayer.model;

import android.net.Uri;

public class Song {
    public final long id;
    public final String title;
    public final String artist;
    public final String albumName;
    public final long albumId;
    public final long durationMs;
    public final Uri contentUri;
    public final int trackNumber;

    public Song(long id, String title, String artist, String albumName, long albumId,
                long durationMs, Uri contentUri, int trackNumber) {
        this.id = id;
        this.title = (title == null || title.trim().isEmpty()) ? "Bilinmeyen parça" : title;
        this.artist = artist == null ? "Bilinmeyen sanatçı" : artist;
        this.albumName = albumName == null ? "Bilinmeyen albüm" : albumName;
        this.albumId = albumId;
        this.durationMs = durationMs;
        this.contentUri = contentUri;
        this.trackNumber = trackNumber;
    }
}
