package com.plakrafi.musicplayer;

import android.os.Bundle;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.plakrafi.musicplayer.adapter.SongAdapter;
import com.plakrafi.musicplayer.data.MusicRepository;
import com.plakrafi.musicplayer.model.Song;

import java.util.List;

public class AlbumSongsActivity extends BaseMusicActivity {

    public static final String EXTRA_ALBUM_ID = "extra_album_id";
    public static final String EXTRA_ALBUM_NAME = "extra_album_name";

    private long albumId;
    private SongAdapter adapter;
    private List<Song> songs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album_songs);

        setupMiniPlayer(findViewById(R.id.miniPlayerRoot));

        albumId = getIntent().getLongExtra(EXTRA_ALBUM_ID, -1);
        String albumName = getIntent().getStringExtra(EXTRA_ALBUM_NAME);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(albumName);
        }

        TextView title = findViewById(R.id.albumSongsTitle);
        title.setText(albumName);

        RecyclerView recyclerView = findViewById(R.id.songRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SongAdapter(this::playSongAt);
        recyclerView.setAdapter(adapter);

        loadSongs();
    }

    private void loadSongs() {
        new Thread(() -> {
            List<Song> result = MusicRepository.getSongsForAlbum(this, albumId);
            runOnUiThread(() -> {
                songs = result;
                adapter.setSongs(songs);
            });
        }).start();
    }

    private void playSongAt(int position) {
        if (songs == null || position < 0 || position >= songs.size()) return;
        startPlaybackWhenReady(songs, position);
        adapter.setPlayingSongId(songs.get(position).id);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onSongChanged(Song song) {
        super.onSongChanged(song);
        if (song != null) {
            runOnUiThread(() -> adapter.setPlayingSongId(song.id));
        }
    }
}
