package com.plakrafi.musicplayer.data;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;

import com.plakrafi.musicplayer.model.Album;
import com.plakrafi.musicplayer.model.Song;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Cihazdaki müzik dosyalarını MediaStore üzerinden tarar.
 * Bu sınıf çağrıldığı thread'i bloklar; UI thread dışında çalıştırılmalı.
 */
public class MusicRepository {

    private static final Uri SONGS_URI = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;

    private static final String[] SONG_PROJECTION = new String[]{
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.TRACK
    };

    /** Tüm albümleri, içindeki parça sayısıyla birlikte döndürür. */
    public static List<Album> getAlbums(Context context) {
        Map<Long, List<Song>> byAlbum = new LinkedHashMap<>();
        List<Song> all = getAllSongs(context);
        for (Song s : all) {
            List<Song> list = byAlbum.get(s.albumId);
            if (list == null) {
                list = new ArrayList<>();
                byAlbum.put(s.albumId, list);
            }
            list.add(s);
        }

        List<Album> albums = new ArrayList<>();
        for (Map.Entry<Long, List<Song>> entry : byAlbum.entrySet()) {
            List<Song> songs = entry.getValue();
            Song first = songs.get(0);
            albums.add(new Album(entry.getKey(), first.albumName, first.artist, songs.size(), first.contentUri));
        }

        Collections.sort(albums, new Comparator<Album>() {
            @Override
            public int compare(Album a, Album b) {
                return a.name.compareToIgnoreCase(b.name);
            }
        });
        return albums;
    }

    /** Belirli bir albümün parçalarını sıra numarasına göre döndürür. */
    public static List<Song> getSongsForAlbum(Context context, long albumId) {
        List<Song> result = new ArrayList<>();
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0 AND " +
                MediaStore.Audio.Media.ALBUM_ID + " = ?";
        String[] args = new String[]{String.valueOf(albumId)};
        String sort = MediaStore.Audio.Media.TRACK + " ASC, " + MediaStore.Audio.Media.TITLE + " ASC";

        try (Cursor cursor = context.getContentResolver().query(
                SONGS_URI, SONG_PROJECTION, selection, args, sort)) {
            readSongs(cursor, result);
        } catch (SecurityException | IllegalStateException ignored) {
            // izin verilmemiş ya da sağlayıcı erişilemez durumda; boş liste döner
        }
        return result;
    }

    /** Cihazdaki tüm müzik dosyalarını tarar (izin gerekir). */
    public static List<Song> getAllSongs(Context context) {
        List<Song> result = new ArrayList<>();
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        String sort = MediaStore.Audio.Media.ALBUM + " ASC, " +
                MediaStore.Audio.Media.TRACK + " ASC";

        try (Cursor cursor = context.getContentResolver().query(
                SONGS_URI, SONG_PROJECTION, selection, null, sort)) {
            readSongs(cursor, result);
        } catch (SecurityException | IllegalStateException ignored) {
            // izin verilmemiş ya da sağlayıcı erişilemez durumda; boş liste döner
        }
        return result;
    }

    private static void readSongs(Cursor cursor, List<Song> out) {
        if (cursor == null) return;
        int idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);
        int titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);
        int artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);
        int albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM);
        int albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID);
        int durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION);
        int trackCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK);

        while (cursor.moveToNext()) {
            long id = cursor.getLong(idCol);
            String title = cursor.getString(titleCol);
            String artist = cursor.getString(artistCol);
            String album = cursor.getString(albumCol);
            long albumId = cursor.getLong(albumIdCol);
            long duration = cursor.getLong(durationCol);
            int track = cursor.getInt(trackCol);
            Uri contentUri = ContentUris.withAppendedId(SONGS_URI, id);
            out.add(new Song(id, title, artist, album, albumId, duration, contentUri, track));
        }
    }
}
