package com.plakrafi.musicplayer;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.plakrafi.musicplayer.data.AlbumArtLoader;
import com.plakrafi.musicplayer.model.Song;

import java.util.Locale;

public class PlayerActivity extends AppCompatActivity implements MusicService.PlaybackListener {

    private MusicService musicService;
    private boolean isBound = false;

    private ImageView cover;
    private TextView title;
    private TextView artist;
    private TextView elapsed;
    private TextView remaining;
    private SeekBar seekBar;
    private ImageView playPauseButton;

    private final Handler progressHandler = new Handler(Looper.getMainLooper());
    private boolean userSeeking = false;

    private final Runnable progressTick = new Runnable() {
        @Override
        public void run() {
            if (musicService != null) {
                musicService.notifyProgressListeners();
            }
            progressHandler.postDelayed(this, 500);
        }
    };

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            musicService = ((MusicService.MusicBinder) service).getService();
            isBound = true;
            musicService.addListener(PlayerActivity.this);
            Song current = musicService.getCurrentSong();
            if (current != null) {
                onSongChanged(current);
                onPlaybackStateChanged(musicService.isPlaying());
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBound = false;
            musicService = null;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.now_playing);
        }

        cover = findViewById(R.id.playerCover);
        title = findViewById(R.id.playerTitle);
        artist = findViewById(R.id.playerArtist);
        elapsed = findViewById(R.id.playerElapsed);
        remaining = findViewById(R.id.playerRemaining);
        seekBar = findViewById(R.id.playerSeekBar);
        playPauseButton = findViewById(R.id.playerPlayPause);

        findViewById(R.id.playerPrev).setOnClickListener(v -> {
            if (musicService != null) musicService.previous();
        });
        findViewById(R.id.playerNext).setOnClickListener(v -> {
            if (musicService != null) musicService.next();
        });
        playPauseButton.setOnClickListener(v -> {
            if (musicService == null) return;
            if (musicService.isPlaying()) musicService.pause(); else musicService.resume();
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                if (fromUser) elapsed.setText(formatTime(progress));
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { userSeeking = true; }
            @Override public void onStopTrackingTouch(SeekBar sb) {
                userSeeking = false;
                if (musicService != null) musicService.seekTo(sb.getProgress());
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        bindService(new Intent(this, MusicService.class), connection, BIND_AUTO_CREATE);
        progressHandler.post(progressTick);
    }

    @Override
    protected void onStop() {
        super.onStop();
        progressHandler.removeCallbacks(progressTick);
        if (isBound) {
            musicService.removeListener(this);
            unbindService(connection);
            isBound = false;
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onSongChanged(Song song) {
        runOnUiThread(() -> {
            if (song == null) return;
            title.setText(song.title);
            artist.setText(song.artist + " · " + song.albumName);
            AlbumArtLoader.loadInto(this, song.albumId, song.contentUri, cover);
            seekBar.setMax(Math.max((int) song.durationMs, 1));
            remaining.setText(formatTime((int) song.durationMs));
        });
    }

    @Override
    public void onPlaybackStateChanged(boolean isPlaying) {
        runOnUiThread(() -> playPauseButton.setImageResource(isPlaying ? R.drawable.ic_pause : R.drawable.ic_play));
    }

    @Override
    public void onProgress(int currentMs, int durationMs) {
        runOnUiThread(() -> {
            if (userSeeking) return;
            if (durationMs > 0) seekBar.setMax(durationMs);
            seekBar.setProgress(currentMs);
            elapsed.setText(formatTime(currentMs));
            remaining.setText(formatTime(Math.max(durationMs - currentMs, 0)));
        });
    }

    private String formatTime(int ms) {
        long totalSec = ms / 1000;
        long min = totalSec / 60;
        long sec = totalSec % 60;
        return String.format(Locale.getDefault(), "%d:%02d", min, sec);
    }
}
