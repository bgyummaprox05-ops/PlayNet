package com.plakrafi.musicplayer.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.plakrafi.musicplayer.R;
import com.plakrafi.musicplayer.data.AlbumArtLoader;
import com.plakrafi.musicplayer.model.Album;

import java.util.ArrayList;
import java.util.List;

public class AlbumAdapter extends RecyclerView.Adapter<AlbumAdapter.ViewHolder> {

    public interface OnAlbumClickListener {
        void onAlbumClick(Album album);
    }

    private final Context context;
    private final OnAlbumClickListener listener;
    private final List<Album> albums = new ArrayList<>();

    public AlbumAdapter(Context context, OnAlbumClickListener listener) {
        this.context = context;
        this.listener = listener;
    }

    public void setAlbums(List<Album> newAlbums) {
        albums.clear();
        albums.addAll(newAlbums);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_album, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Album album = albums.get(position);
        holder.name.setText(album.name);
        holder.meta.setText(context.getResources().getQuantityString(R.plurals.song_count, album.songCount, album.songCount));
        AlbumArtLoader.loadInto(context, album.id, album.sampleSongUri, holder.cover);
        holder.itemView.setOnClickListener(v -> listener.onAlbumClick(album));
    }

    @Override
    public int getItemCount() {
        return albums.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView cover;
        TextView name;
        TextView meta;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            cover = itemView.findViewById(R.id.albumCover);
            name = itemView.findViewById(R.id.albumName);
            meta = itemView.findViewById(R.id.albumMeta);
        }
    }
}
