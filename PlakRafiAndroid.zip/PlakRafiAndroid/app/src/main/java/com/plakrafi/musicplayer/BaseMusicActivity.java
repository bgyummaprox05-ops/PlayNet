package com.plakrafi.musicplayer;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.plakrafi.musicplayer.data.AlbumArtLoader;
import com.plakrafi.musicplayer.model.Song;

public abstract class BaseMusicActivity extends AppCompatActivity implements MusicService.PlaybackListener {

    protected MusicService musicService;
    protected boolean isBound = false;

    private View miniPlayerRoot;
    private ImageView miniCover;
    private TextView miniTitle;
    private TextView miniArtist;
    private ImageView miniPlayPause;

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            musicService = ((MusicService.MusicBinder) service).getService();
            isBound = true;
            musicService.addListener(BaseMusicActivity.this);
            Song current = musicService.getCurrentSong();
            if (current != null) {
                onSongChanged(current);
                onPlaybackStateChanged(musicService.isPlaying());
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBound = false;
            musicService = null;
        }
    };

    /** Alt sınıf, düzeninde mini_player.xml include edilen kök view'i verir. */
    protected void setupMiniPlayer(View miniRoot) {
        miniPlayerRoot = miniRoot;
        miniCover = miniRoot.findViewById(R.id.miniCover);
        miniTitle = miniRoot.findViewById(R.id.miniTitle);
        miniArtist = miniRoot.findViewById(R.id.miniArtist);
        miniPlayPause = miniRoot.findViewById(R.id.miniPlayPause);

        miniPlayerRoot.setVisibility(View.GONE);

        miniPlayPause.setOnClickListener(v -> {
            if (musicService == null) return;
            if (musicService.isPlaying()) musicService.pause(); else musicService.resume();
        });
        miniPlayerRoot.setOnClickListener(v -> startActivity(new Intent(this, PlayerActivity.class)));
    }

    @Override
    protected void onStart() {
        super.onStart();
        Intent intent = new Intent(this, MusicService.class);
        bindService(intent, connection, BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (isBound) {
            musicService.removeListener(this);
            unbindService(connection);
            isBound = false;
        }
    }

    @Override
    public void onSongChanged(Song song) {
        runOnUiThread(() -> {
            if (miniPlayerRoot == null) return;
            if (song == null) {
                miniPlayerRoot.setVisibility(View.GONE);
                return;
            }
            miniPlayerRoot.setVisibility(View.VISIBLE);
            miniTitle.setText(song.title);
            miniArtist.setText(song.artist);
            AlbumArtLoader.loadInto(this, song.albumId, song.contentUri, miniCover);
        });
    }

    @Override
    public void onPlaybackStateChanged(boolean isPlaying) {
        runOnUiThread(() -> {
            if (miniPlayPause == null) return;
            miniPlayPause.setImageResource(isPlaying ? R.drawable.ic_pause : R.drawable.ic_play);
        });
    }

    @Override
    public void onProgress(int currentMs, int durationMs) {
        // Mini çalar ilerleme çubuğu göstermiyor; PlayerActivity kendi sürümünü dinler.
    }

    /** Servise bağlanmışsa çalmaya başlar; henüz bağlanmadıysa kısa süre sonra tekrar dener. */
    protected void startPlaybackWhenReady(java.util.List<Song> songs, int index) {
        Intent svcIntent = new Intent(this, MusicService.class);
        androidx.core.content.ContextCompat.startForegroundService(this, svcIntent);
        if (isBound && musicService != null) {
            musicService.playQueue(songs, index);
        } else {
            bindService(svcIntent, new ServiceConnection() {
                @Override
                public void onServiceConnected(ComponentName name, IBinder service) {
                    MusicService s = ((MusicService.MusicBinder) service).getService();
                    s.playQueue(songs, index);
                    unbindService(this);
                }

                @Override
                public void onServiceDisconnected(ComponentName name) {
                }
            }, BIND_AUTO_CREATE);
        }
    }
}
