package com.plakrafi.musicplayer.data;

import android.content.ContentUris;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Albüm kapaklarını arka planda yükler ve bellekte önbelleğe alır.
 * Önce hızlı "albumart" içerik URI'sini dener; bulamazsa parça dosyasının
 * içine gömülü kapak resmini (varsa) çıkarır. İkisi de yoksa görsel boş bırakılır
 * ve ImageView'in XML'de tanımlı yer tutucu (placeholder) çizimi görünür kalır.
 */
public class AlbumArtLoader {

    private static final LruCache<Long, Bitmap> CACHE =
            new LruCache<Long, Bitmap>(48) {
                @Override
                protected int sizeOf(Long key, Bitmap value) {
                    return value.getByteCount() / 1024;
                }
            };

    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(3);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    public static void loadInto(Context appContext, long albumId, Uri sampleSongUri, ImageView imageView) {
        imageView.setTag(albumId);
        imageView.setImageDrawable(null);

        Bitmap cached = CACHE.get(albumId);
        if (cached != null) {
            imageView.setImageBitmap(cached);
            return;
        }

        final Context ctx = appContext.getApplicationContext();
        EXECUTOR.execute(() -> {
            Bitmap bitmap = decodeFastPath(ctx, albumId);
            if (bitmap == null && sampleSongUri != null) {
                bitmap = decodeEmbedded(ctx, sampleSongUri);
            }
            final Bitmap result = bitmap;
            if (result != null) {
                CACHE.put(albumId, result);
            }
            MAIN.post(() -> {
                Object tag = imageView.getTag();
                if (tag instanceof Long && (Long) tag == albumId && result != null) {
                    imageView.setImageBitmap(result);
                }
            });
        });
    }

    /** Bildirim gibi senkron bir bitmap gereken yerler için doğrudan (bloklayan) yükleme. */
    public static Bitmap loadBitmapSync(Context appContext, long albumId, Uri sampleSongUri) {
        Bitmap cached = CACHE.get(albumId);
        if (cached != null) return cached;
        Context ctx = appContext.getApplicationContext();
        Bitmap bitmap = decodeFastPath(ctx, albumId);
        if (bitmap == null && sampleSongUri != null) {
            bitmap = decodeEmbedded(ctx, sampleSongUri);
        }
        if (bitmap != null) {
            CACHE.put(albumId, bitmap);
        }
        return bitmap;
    }

    private static Bitmap decodeFastPath(Context ctx, long albumId) {
        Uri artUri = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId);
        try (InputStream is = ctx.getContentResolver().openInputStream(artUri)) {
            if (is == null) return null;
            return BitmapFactory.decodeStream(is);
        } catch (Exception e) {
            return null;
        }
    }

    private static Bitmap decodeEmbedded(Context ctx, Uri songUri) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(ctx, songUri);
            byte[] art = retriever.getEmbeddedPicture();
            if (art == null) return null;
            return BitmapFactory.decodeByteArray(art, 0, art.length);
        } catch (Exception e) {
            return null;
        } finally {
            try {
                retriever.release();
            } catch (Exception ignored) {
            }
        }
    }
}
