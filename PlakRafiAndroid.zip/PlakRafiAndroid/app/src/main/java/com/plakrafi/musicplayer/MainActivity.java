package com.plakrafi.musicplayer;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.plakrafi.musicplayer.adapter.AlbumAdapter;
import com.plakrafi.musicplayer.data.MusicRepository;
import com.plakrafi.musicplayer.model.Album;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends BaseMusicActivity {

    private RecyclerView recyclerView;
    private AlbumAdapter adapter;
    private View emptyState;
    private View permissionState;
    private TextView permissionMessage;

    private final ActivityResultLauncher<String[]> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                if (hasStoragePermission()) {
                    loadAlbums();
                } else {
                    showPermissionState();
                }
            });

    @Override
    protected void onCreate(@androidx.annotation.Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupMiniPlayer(findViewById(R.id.miniPlayerRoot));

        recyclerView = findViewById(R.id.albumRecyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new AlbumAdapter(this, this::openAlbum);
        recyclerView.setAdapter(adapter);

        emptyState = findViewById(R.id.emptyState);
        permissionState = findViewById(R.id.permissionState);
        permissionMessage = findViewById(R.id.permissionMessage);
        findViewById(R.id.grantPermissionButton).setOnClickListener(v -> requestPermissions());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (hasStoragePermission()) {
            loadAlbums();
        } else {
            requestPermissions();
        }
    }

    private boolean hasStoragePermission() {
        String permission = Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_AUDIO
                : Manifest.permission.READ_EXTERNAL_STORAGE;
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermissions() {
        List<String> perms = new ArrayList<>();
        perms.add(Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_AUDIO
                : Manifest.permission.READ_EXTERNAL_STORAGE);
        if (Build.VERSION.SDK_INT >= 33) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        permissionLauncher.launch(perms.toArray(new String[0]));
    }

    private void showPermissionState() {
        recyclerView.setVisibility(View.GONE);
        emptyState.setVisibility(View.GONE);
        permissionState.setVisibility(View.VISIBLE);
        permissionMessage.setText(R.string.permission_rationale);
    }

    private void loadAlbums() {
        permissionState.setVisibility(View.GONE);
        new Thread(() -> {
            List<Album> albums = MusicRepository.getAlbums(this);
            runOnUiThread(() -> {
                adapter.setAlbums(albums);
                boolean empty = albums.isEmpty();
                emptyState.setVisibility(empty ? View.VISIBLE : View.GONE);
                recyclerView.setVisibility(empty ? View.GONE : View.VISIBLE);
            });
        }).start();
    }

    private void openAlbum(Album album) {
        Intent intent = new Intent(this, AlbumSongsActivity.class);
        intent.putExtra(AlbumSongsActivity.EXTRA_ALBUM_ID, album.id);
        intent.putExtra(AlbumSongsActivity.EXTRA_ALBUM_NAME, album.name);
        startActivity(intent);
    }
}
