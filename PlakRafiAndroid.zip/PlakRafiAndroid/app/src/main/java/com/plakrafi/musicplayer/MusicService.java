package com.plakrafi.musicplayer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.media.app.NotificationCompat.MediaStyle;

import com.plakrafi.musicplayer.data.AlbumArtLoader;
import com.plakrafi.musicplayer.model.Song;

import java.util.ArrayList;
import java.util.List;

public class MusicService extends Service {

    public static final String ACTION_TOGGLE = "com.plakrafi.musicplayer.ACTION_TOGGLE";
    public static final String ACTION_NEXT = "com.plakrafi.musicplayer.ACTION_NEXT";
    public static final String ACTION_PREV = "com.plakrafi.musicplayer.ACTION_PREV";
    public static final String ACTION_STOP = "com.plakrafi.musicplayer.ACTION_STOP";

    private static final String CHANNEL_ID = "plakrafi_playback_channel";
    private static final int NOTIF_ID = 1001;

    public interface PlaybackListener {
        void onSongChanged(Song song);
        void onPlaybackStateChanged(boolean isPlaying);
        void onProgress(int currentMs, int durationMs);
    }

    public class MusicBinder extends Binder {
        public MusicService getService() {
            return MusicService.this;
        }
    }

    private final IBinder binder = new MusicBinder();
    private final List<PlaybackListener> listeners = new ArrayList<>();

    private MediaPlayer player;
    private final List<Song> queue = new ArrayList<>();
    private int currentIndex = -1;
    private boolean preparing = false;

    private MediaSessionCompat mediaSession;
    private AudioManager audioManager;
    private AudioFocusRequest focusRequest;
    private boolean resumeOnFocusGain = false;

    private final BroadcastReceiver noisyReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (AudioManager.ACTION_AUDIO_BECOMING_NOISY.equals(intent.getAction())) {
                if (isPlaying()) pause();
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        createPlayer();
        createNotificationChannel();
        initMediaSession();
        registerReceiver(noisyReceiver, new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
    }

    private void createPlayer() {
        player = new MediaPlayer();
        player.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build());
        player.setOnPreparedListener(mp -> {
            preparing = false;
            mp.start();
            notifyPlaybackState(true);
            updateNotification();
        });
        player.setOnCompletionListener(mp -> next());
        player.setOnErrorListener((mp, what, extra) -> {
            preparing = false;
            next();
            return true;
        });
    }

    private void initMediaSession() {
        mediaSession = new MediaSessionCompat(this, "PlakRafiSession");
        mediaSession.setCallback(new MediaSessionCompat.Callback() {
            @Override public void onPlay() { resume(); }
            @Override public void onPause() { pause(); }
            @Override public void onSkipToNext() { next(); }
            @Override public void onSkipToPrevious() { previous(); }
            @Override public void onSeekTo(long pos) { seekTo((int) pos); }
            @Override public void onStop() { stopPlaybackAndService(); }
        });
        mediaSession.setActive(true);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID, "Müzik çalma", NotificationManager.IMPORTANCE_LOW);
                channel.setDescription("Şu an çalan parça bildirimi");
                channel.setShowBadge(false);
                nm.createNotificationChannel(channel);
            }
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            switch (intent.getAction()) {
                case ACTION_TOGGLE:
                    if (isPlaying()) pause(); else resume();
                    break;
                case ACTION_NEXT:
                    next();
                    break;
                case ACTION_PREV:
                    previous();
                    break;
                case ACTION_STOP:
                    stopPlaybackAndService();
                    break;
            }
        }
        return START_NOT_STICKY;
    }

    /* ---------------- playback control ---------------- */

    public void playQueue(List<Song> songs, int startIndex) {
        if (songs == null || songs.isEmpty() || startIndex < 0 || startIndex >= songs.size()) return;
        queue.clear();
        queue.addAll(songs);
        currentIndex = startIndex;
        startCurrent();
    }

    private void startCurrent() {
        if (currentIndex < 0 || currentIndex >= queue.size()) return;
        if (!requestAudioFocus()) return;

        Song song = queue.get(currentIndex);
        try {
            preparing = true;
            player.reset();
            player.setDataSource(this, song.contentUri);
            player.prepareAsync();
            notifySongChanged(song);
            updateMediaSessionMetadata(song);
        } catch (Exception e) {
            preparing = false;
            next();
        }
    }

    public void resume() {
        if (player == null) return;
        if (currentIndex == -1 && !queue.isEmpty()) {
            currentIndex = 0;
            startCurrent();
            return;
        }
        if (!preparing && !player.isPlaying()) {
            if (!requestAudioFocus()) return;
            try {
                player.start();
                notifyPlaybackState(true);
                updateNotification();
            } catch (IllegalStateException ignored) {
            }
        }
    }

    public void pause() {
        if (player != null && player.isPlaying()) {
            player.pause();
            notifyPlaybackState(false);
            updateNotification();
        }
    }

    public void next() {
        if (queue.isEmpty()) return;
        currentIndex = (currentIndex + 1) % queue.size();
        startCurrent();
    }

    public void previous() {
        if (queue.isEmpty()) return;
        currentIndex = (currentIndex - 1 + queue.size()) % queue.size();
        startCurrent();
    }

    public void seekTo(int ms) {
        if (player != null && !preparing) {
            try {
                player.seekTo(ms);
            } catch (IllegalStateException ignored) {
            }
        }
    }

    public boolean isPlaying() {
        try {
            return player != null && player.isPlaying();
        } catch (IllegalStateException e) {
            return false;
        }
    }

    public int getCurrentPosition() {
        try {
            return (player != null && !preparing) ? player.getCurrentPosition() : 0;
        } catch (IllegalStateException e) {
            return 0;
        }
    }

    public int getDuration() {
        try {
            return (player != null && !preparing) ? player.getDuration() : 0;
        } catch (IllegalStateException e) {
            return 0;
        }
    }

    @Nullable
    public Song getCurrentSong() {
        if (currentIndex < 0 || currentIndex >= queue.size()) return null;
        return queue.get(currentIndex);
    }

    private void stopPlaybackAndService() {
        if (player != null) {
            try {
                player.stop();
            } catch (IllegalStateException ignored) {
            }
        }
        notifyPlaybackState(false);
        stopForeground(true);
        stopSelf();
    }

    /* ---------------- listeners ---------------- */

    public void addListener(PlaybackListener l) {
        if (!listeners.contains(l)) listeners.add(l);
    }

    public void removeListener(PlaybackListener l) {
        listeners.remove(l);
    }

    private void notifySongChanged(Song song) {
        for (PlaybackListener l : listeners) l.onSongChanged(song);
    }

    private void notifyPlaybackState(boolean playing) {
        for (PlaybackListener l : listeners) l.onPlaybackStateChanged(playing);
        updatePlaybackStateForSession(playing);
    }

    public void notifyProgressListeners() {
        int pos = getCurrentPosition();
        int dur = getDuration();
        for (PlaybackListener l : listeners) l.onProgress(pos, dur);
    }

    /* ---------------- audio focus ---------------- */

    private boolean requestAudioFocus() {
        if (audioManager == null) return true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (focusRequest == null) {
                AudioAttributes attrs = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build();
                focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                        .setAudioAttributes(attrs)
                        .setOnAudioFocusChangeListener(this::onFocusChange)
                        .build();
            }
            int result = audioManager.requestAudioFocus(focusRequest);
            return result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        } else {
            int result = audioManager.requestAudioFocus(this::onFocusChange,
                    AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
            return result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        }
    }

    private void onFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
                resumeOnFocusGain = false;
                pause();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                resumeOnFocusGain = isPlaying();
                pause();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                if (player != null) player.setVolume(0.3f, 0.3f);
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                if (player != null) player.setVolume(1f, 1f);
                if (resumeOnFocusGain) {
                    resumeOnFocusGain = false;
                    resume();
                }
                break;
        }
    }

    /* ---------------- media session + notification ---------------- */

    public MediaSessionCompat getMediaSession() {
        return mediaSession;
    }

    private void updateMediaSessionMetadata(Song song) {
        // Başlık/sanatçı bilgisi bildirimde ve kilit ekranında gösterilir.
        android.support.v4.media.MediaMetadataCompat.Builder builder =
                new android.support.v4.media.MediaMetadataCompat.Builder()
                        .putString(android.support.v4.media.MediaMetadataCompat.METADATA_KEY_TITLE, song.title)
                        .putString(android.support.v4.media.MediaMetadataCompat.METADATA_KEY_ARTIST, song.artist)
                        .putString(android.support.v4.media.MediaMetadataCompat.METADATA_KEY_ALBUM, song.albumName)
                        .putLong(android.support.v4.media.MediaMetadataCompat.METADATA_KEY_DURATION, song.durationMs);
        Bitmap art = AlbumArtLoader.loadBitmapSync(this, song.albumId, song.contentUri);
        if (art != null) {
            builder.putBitmap(android.support.v4.media.MediaMetadataCompat.METADATA_KEY_ALBUM_ART, art);
        }
        mediaSession.setMetadata(builder.build());
    }

    private void updatePlaybackStateForSession(boolean playing) {
        if (mediaSession == null) return;
        long actions = PlaybackStateCompat.ACTION_PLAY | PlaybackStateCompat.ACTION_PAUSE |
                PlaybackStateCompat.ACTION_PLAY_PAUSE | PlaybackStateCompat.ACTION_SKIP_TO_NEXT |
                PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS | PlaybackStateCompat.ACTION_SEEK_TO;
        PlaybackStateCompat state = new PlaybackStateCompat.Builder()
                .setActions(actions)
                .setState(playing ? PlaybackStateCompat.STATE_PLAYING : PlaybackStateCompat.STATE_PAUSED,
                        getCurrentPosition(), 1f)
                .build();
        mediaSession.setPlaybackState(state);
    }

    private void updateNotification() {
        Song song = getCurrentSong();
        if (song == null) return;

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;

        PendingIntent togglePi = servicePendingIntent(ACTION_TOGGLE, 1, flags);
        PendingIntent nextPi = servicePendingIntent(ACTION_NEXT, 2, flags);
        PendingIntent prevPi = servicePendingIntent(ACTION_PREV, 3, flags);
        PendingIntent stopPi = servicePendingIntent(ACTION_STOP, 4, flags);

        boolean playing = isPlaying();
        Bitmap art = AlbumArtLoader.loadBitmapSync(this, song.albumId, song.contentUri);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(song.title)
                .setContentText(song.artist)
                .setLargeIcon(art)
                .setOnlyAlertOnce(true)
                .setOngoing(playing)
                .addAction(R.drawable.ic_prev, "Önceki", prevPi)
                .addAction(playing ? R.drawable.ic_pause : R.drawable.ic_play,
                        playing ? "Duraklat" : "Oynat", togglePi)
                .addAction(R.drawable.ic_next, "Sonraki", nextPi)
                .setDeleteIntent(stopPi)
                .setStyle(new MediaStyle()
                        .setMediaSession(mediaSession.getSessionToken())
                        .setShowActionsInCompactView(0, 1, 2))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC);

        Notification notification = builder.build();

        if (playing) {
            startForeground(NOTIF_ID, notification);
        } else {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, notification);
            stopForeground(false);
        }
    }

    private PendingIntent servicePendingIntent(String action, int requestCode, int flags) {
        Intent intent = new Intent(this, MusicService.class);
        intent.setAction(action);
        return PendingIntent.getService(this, requestCode, intent, flags);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(noisyReceiver);
        } catch (IllegalArgumentException ignored) {
        }
        if (player != null) {
            player.release();
            player = null;
        }
        if (mediaSession != null) {
            mediaSession.setActive(false);
            mediaSession.release();
        }
        if (audioManager != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && focusRequest != null) {
                audioManager.abandonAudioFocusRequest(focusRequest);
            }
        }
    }
}
