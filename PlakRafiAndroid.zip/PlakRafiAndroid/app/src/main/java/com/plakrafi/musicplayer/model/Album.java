package com.plakrafi.musicplayer.model;

import android.net.Uri;

public class Album {
    public final long id;
    public final String name;
    public final String artist;
    public final int songCount;
    /** Kapak resmini gömülü sanattan çıkarmak için örnek bir parça URI'si. */
    public final Uri sampleSongUri;

    public Album(long id, String name, String artist, int songCount, Uri sampleSongUri) {
        this.id = id;
        this.name = name == null ? "Bilinmeyen albüm" : name;
        this.artist = artist == null ? "Bilinmeyen sanatçı" : artist;
        this.songCount = songCount;
        this.sampleSongUri = sampleSongUri;
    }
}
